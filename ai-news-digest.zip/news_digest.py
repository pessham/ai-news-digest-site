#!/usr/bin/env python3
"""毎朝6時のAIニュース便"""

import os
import re
import pickle
import smtplib
import feedparser
from datetime import date
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).parent
load_dotenv(BASE_DIR / ".env")

GMAIL_ADDRESS   = os.getenv("GMAIL_ADDRESS")
APP_PASSWORD    = os.getenv("GMAIL_APP_PASSWORD", "").replace(" ", "")
EMAIL_TO        = os.getenv("EMAIL_TO", GMAIL_ADDRESS)
API_KEY         = os.getenv("ANTHROPIC_API_KEY")
USE_SHEETS      = os.getenv("USE_SHEETS", "false").lower() == "true"
GOOGLE_EMAIL    = os.getenv("GOOGLE_EMAIL", GMAIL_ADDRESS)

LAST_RUN_FILE   = BASE_DIR / "last_run.txt"

RSS_FEEDS = [
    # 日本語メディア
    ("ITmedia AI+",   "https://rss.itmedia.co.jp/rss/2.0/aiplus.xml"),
    ("AINOW",         "https://ainow.ai/feed/"),
    ("日経xTECH",     "https://xtech.nikkei.com/rss/xtech-it.rdf"),
    # 英語メディア
    ("TechCrunch AI", "https://techcrunch.com/category/artificial-intelligence/feed/"),
    ("VentureBeat AI","https://venturebeat.com/category/ai/feed/"),
]

MAX_PER_FEED = 3


# ── ユーティリティ ──────────────────────────────────────

def strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text or "").strip()


def already_ran_today() -> bool:
    return LAST_RUN_FILE.exists() and LAST_RUN_FILE.read_text().strip() == str(date.today())


def mark_ran():
    LAST_RUN_FILE.write_text(str(date.today()))


# ── ニュース収集 ────────────────────────────────────────

def fetch_news() -> list[dict]:
    articles = []
    for source, url in RSS_FEEDS:
        feed = feedparser.parse(url)
        for entry in feed.entries[:MAX_PER_FEED]:
            desc = strip_html(entry.get("summary", entry.get("description", "")))
            articles.append({
                "source":      source,
                "title":       entry.get("title", "").strip(),
                "description": desc,
                "link":        entry.get("link", ""),
            })
    return articles


# ── 要約 ────────────────────────────────────────────────

def summarize_with_claude(article: dict) -> str:
    import anthropic
    client = anthropic.Anthropic(api_key=API_KEY)
    resp = client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=150,
        messages=[{
            "role": "user",
            "content": (
                "以下のAIニュースを日本語で2〜3文に要約してください。\n\n"
                f"タイトル: {article['title']}\n"
                f"内容: {article['description']}"
            ),
        }],
    )
    return resp.content[0].text.strip()


def get_summary(article: dict) -> str:
    if API_KEY:
        try:
            return summarize_with_claude(article)
        except Exception as e:
            print(f"  Claude APIエラー（RSS本文を使用）: {e}")
    desc = article["description"]
    return desc[:280] + ("…" if len(desc) > 280 else "")


# ── メール送信 ───────────────────────────────────────────

def build_email_html(articles: list[dict], today: date) -> tuple[str, str]:
    mode_label = "Claude AI要約" if API_KEY else "RSS配信"
    mode_color = "#667eea" if API_KEY else "#888"

    date_str = today.strftime("%Y年%m月%d日")
    subject   = f"【AIニュース便】{date_str}のAIニュース"

    cards = ""
    for a in articles:
        cards += f"""
      <div style="border-left:3px solid #667eea;padding:12px 16px;margin:14px 0;
                  background:#f8f8ff;border-radius:0 8px 8px 0;">
        <div style="font-size:11px;color:#667eea;font-weight:bold;
                    text-transform:uppercase;margin-bottom:4px;">{a['source']}</div>
        <div style="font-size:15px;font-weight:bold;margin:0 0 6px;">
          <a href="{a['link']}" style="color:#1a1a2e;text-decoration:none;">{a['title']}</a>
        </div>
        <p style="font-size:13px;color:#444;line-height:1.7;margin:0;">{a['summary']}</p>
      </div>"""

    html = f"""<!DOCTYPE html>
<html lang="ja"><head><meta charset="UTF-8"></head>
<body style="font-family:-apple-system,sans-serif;background:#f0f0f5;margin:0;padding:20px;">
  <div style="max-width:600px;margin:0 auto;">
    <div style="background:#1a1a2e;color:white;padding:28px;text-align:center;border-radius:10px 10px 0 0;">
      <div style="font-size:22px;font-weight:bold;">毎朝6時のAIニュース便</div>
      <div style="opacity:.7;margin-top:6px;">{date_str}</div>
      <div style="display:inline-block;background:{mode_color};padding:3px 10px;
                  border-radius:20px;font-size:11px;margin-top:8px;">{mode_label}</div>
    </div>
    <div style="background:white;padding:24px;border-radius:0 0 10px 10px;">
      {cards}
    </div>
    <div style="text-align:center;padding:16px;font-size:11px;color:#999;">
      毎朝6時のAIニュース便 · 自動配信
    </div>
  </div>
</body></html>"""

    return subject, html


def send_email(subject: str, html: str):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = GMAIL_ADDRESS
    msg["To"]      = EMAIL_TO
    msg.attach(MIMEText(html, "html", "utf-8"))

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(GMAIL_ADDRESS, APP_PASSWORD)
        server.sendmail(GMAIL_ADDRESS, EMAIL_TO, msg.as_string())


# ── Googleスプレッドシート ──────────────────────────────

def get_google_client():
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request
    import gspread

    SCOPES = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive",
    ]
    token_path = BASE_DIR / "token.pickle"
    creds_path = BASE_DIR / "credentials.json"
    creds = None

    if token_path.exists():
        with open(token_path, "rb") as f:
            creds = pickle.load(f)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not creds_path.exists():
                print("⚠️  credentials.jsonが見つかりません。setup.shのStep 3を確認してください。")
                return None
            flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
            creds = flow.run_local_server(port=0)
        with open(token_path, "wb") as f:
            pickle.dump(creds, f)

    return gspread.authorize(creds)


def save_to_sheets(articles: list[dict], today: date):
    gc = get_google_client()
    if not gc:
        return

    try:
        sh = gc.open("AIニュース便")
    except Exception:
        sh = gc.create("AIニュース便")
        sh.share(GOOGLE_EMAIL, perm_type="user", role="writer")
        print(f"  ✅ スプレッドシート作成: {sh.url}")

    sheet_name = today.strftime("%Y-%m-%d")
    try:
        ws = sh.worksheet(sheet_name)
    except Exception:
        ws = sh.add_worksheet(title=sheet_name, rows=100, cols=5)
        ws.append_row(["日付", "ソース", "タイトル", "要約", "URL"])

    rows = [
        [str(today), a["source"], a["title"], a["summary"], a["link"]]
        for a in articles
    ]
    ws.append_rows(rows)
    print(f"  ✅ スプレッドシートに記録 ({len(articles)}件)")


# ── メイン ───────────────────────────────────────────────

def main():
    if already_ran_today():
        print(f"✅ 本日({date.today()})はすでに配信済みです。")
        return

    today = date.today()
    print(f"📡 AIニュースを収集中... ({today})")

    articles = fetch_news()
    print(f"  {len(articles)}件取得")

    mode = "Claude AI" if API_KEY else "RSS本文"
    print(f"✍️  要約中（{mode}）...")
    for a in articles:
        a["summary"] = get_summary(a)

    print(f"📧 メール送信中 → {EMAIL_TO}")
    subject, html = build_email_html(articles, today)
    send_email(subject, html)
    print("  ✅ 送信完了")

    if USE_SHEETS:
        print("📊 スプレッドシートに記録中...")
        save_to_sheets(articles, today)

    mark_ran()
    print("🎉 完了！")


if __name__ == "__main__":
    main()

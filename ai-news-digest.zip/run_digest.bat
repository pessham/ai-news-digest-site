@echo off
chcp 65001 > nul
cd /d "%~dp0"
set SCRIPT_DIR=%~dp0

echo.
echo ==============================
echo   毎朝6時のAIニュース便
echo ==============================
echo.

:: ── Pythonチェック ──────────────────────────────────────
python --version > nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Pythonがインストールされていません。
    echo.
    echo     https://www.python.org/downloads/ を開きます。
    echo     「Download Python」ボタンを押してインストールしてください。
    echo     インストール時に「Add Python to PATH」に必ずチェックを入れてください。
    echo.
    echo     インストール完了後、もう一度 run_digest.bat をダブルクリックしてください。
    echo.
    start https://www.python.org/downloads/
    pause
    exit /b
)

:: ── パッケージチェック ──────────────────────────────────
python -c "import feedparser" > nul 2>&1
if %errorlevel% neq 0 (
    echo [*] 必要なパッケージをインストールしています...
    pip install feedparser python-dotenv anthropic gspread google-auth google-auth-oauthlib google-auth-httplib2 --quiet
    echo     インストール完了
    echo.
)

:: ── .envチェック ────────────────────────────────────────
if not exist "%SCRIPT_DIR%.env" (
    echo [!] .envファイルが見つかりません。
    echo.
    echo     .env.example をコピーして .env という名前にし、
    echo     メモ帳でGMAIL_ADDRESSとGMAIL_APP_PASSWORDを入力してください。
    echo.
    echo     設定完了後、もう一度 run_digest.bat をダブルクリックしてください。
    echo.
    explorer "%SCRIPT_DIR%"
    pause
    exit /b
)

:: ── タスクスケジューラ登録（未登録なら自動登録）──────────
schtasks /query /tn "AIニュース便" > nul 2>&1
if %errorlevel% neq 0 (
    echo [*] 毎朝6時の自動実行を登録しています...

    :: XML一時ファイルで StartWhenAvailable を有効化
    set XML_PATH=%TEMP%\ainews_task.xml
    (
    echo ^<?xml version="1.0" encoding="UTF-16"?^>
    echo ^<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task"^>
    echo   ^<Triggers^>
    echo     ^<CalendarTrigger^>
    echo       ^<StartBoundary^>2026-01-01T06:00:00^</StartBoundary^>
    echo       ^<ScheduleByDay^>^<DaysInterval^>1^</DaysInterval^>^</ScheduleByDay^>
    echo     ^</CalendarTrigger^>
    echo   ^</Triggers^>
    echo   ^<Settings^>
    echo     ^<StartWhenAvailable^>true^</StartWhenAvailable^>
    echo     ^<ExecutionTimeLimit^>PT1H^</ExecutionTimeLimit^>
    echo   ^</Settings^>
    echo   ^<Actions^>
    echo     ^<Exec^>
    echo       ^<Command^>pythonw^</Command^>
    echo       ^<Arguments^>"%SCRIPT_DIR%news_digest.py"^</Arguments^>
    echo       ^<WorkingDirectory^>%SCRIPT_DIR%^</WorkingDirectory^>
    echo     ^</Exec^>
    echo   ^</Actions^>
    echo ^</Task^>
    ) > "%XML_PATH%"

    schtasks /create /tn "AIニュース便" /xml "%XML_PATH%" /f > nul
    del "%XML_PATH%"
    echo     毎朝6時に自動実行されます（6時に電源OFFでも起動後に届きます）
    echo.
)

:: ── メイン実行 ──────────────────────────────────────────
python "%SCRIPT_DIR%news_digest.py"

echo.
echo ==============================
echo   Press any key to close...
echo ==============================
pause > nul

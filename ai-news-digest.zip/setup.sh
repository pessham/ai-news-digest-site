#!/bin/bash
# =============================================
# 毎朝6時のAIニュース便 セットアップスクリプト
# =============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON="$(which python3)"
PLIST_NAME="com.ainewsdigest.daily"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"

echo ""
echo "================================================"
echo "  毎朝6時のAIニュース便 セットアップ"
echo "================================================"
echo ""

# ── Step 1: Pythonパッケージのインストール ──
echo "📦 Step 1: 必要なパッケージをインストール中..."
pip3 install --quiet feedparser python-dotenv anthropic \
             gspread google-auth google-auth-oauthlib google-auth-httplib2
echo "  ✅ インストール完了"
echo ""

# ── Step 2: .envファイルの作成 ──
echo "⚙️  Step 2: 設定ファイルの確認..."
if [ ! -f "$SCRIPT_DIR/.env" ]; then
    cp "$SCRIPT_DIR/.env.example" "$SCRIPT_DIR/.env"
    echo "  ✅ .envファイルを作成しました"
    echo ""
    echo "  ⚠️  次の手順で.envを編集してください："
    echo "  1. GMAIL_APP_PASSWORDを設定する"
    echo "     → Googleアカウント > セキュリティ > 2段階認証をON"
    echo "     → アプリパスワードを生成 > 生成されたコードを貼る"
    echo ""
    echo "  設定後、もう一度このsetup.shを実行してください。"
    open "$SCRIPT_DIR/.env"
    exit 0
else
    echo "  ✅ .envファイルが存在します"
fi
echo ""

# .envを読み込んで確認
source "$SCRIPT_DIR/.env" 2>/dev/null || true
if [ -z "$GMAIL_APP_PASSWORD" ] || [ "$GMAIL_APP_PASSWORD" = "xxxx-xxxx-xxxx-xxxx" ]; then
    echo "  ⚠️  GMAIL_APP_PASSWORDが未設定です。.envを編集してください。"
    open "$SCRIPT_DIR/.env"
    exit 1
fi

# ── Step 3: Googleスプレッドシート（オプション）──
if [ "${USE_SHEETS}" = "true" ]; then
    echo "📊 Step 3: Googleスプレッドシートのセットアップ..."
    if [ ! -f "$SCRIPT_DIR/credentials.json" ]; then
        echo ""
        echo "  credentials.jsonが必要です。以下の手順で取得してください："
        echo ""
        echo "  1. https://console.cloud.google.com/ を開く"
        echo "  2. 新しいプロジェクトを作成（例: ai-news-digest）"
        echo "  3. 「APIとサービス」→「ライブラリ」で以下を有効化："
        echo "     - Google Sheets API"
        echo "     - Google Drive API"
        echo "  4. 「認証情報」→「認証情報を作成」→「OAuthクライアントID」"
        echo "     アプリケーションの種類: デスクトップアプリ"
        echo "  5. JSONをダウンロードして credentials.json という名前で"
        echo "     このフォルダに保存: $SCRIPT_DIR/"
        echo ""
        echo "  ⚠️  設定後、もう一度setup.shを実行してください。"
        exit 1
    fi
    echo "  ✅ credentials.jsonが存在します（初回実行時にブラウザ認証が開きます）"
    echo ""
fi

# ── Step 4: LaunchAgent（毎朝6時の自動実行）──
echo "⏰ Step 4: 毎朝6時の自動実行を設定中..."

mkdir -p "$HOME/Library/LaunchAgents"

cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${PLIST_NAME}</string>
    <key>ProgramArguments</key>
    <array>
        <string>${PYTHON}</string>
        <string>${SCRIPT_DIR}/news_digest.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>6</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>StandardErrorPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>WorkingDirectory</key>
    <string>${SCRIPT_DIR}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
        <key>HOME</key>
        <string>${HOME}</string>
    </dict>
    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
EOF

launchctl unload "$PLIST_PATH" 2>/dev/null || true
launchctl load "$PLIST_PATH"
echo "  ✅ LaunchAgent設定完了（毎朝6時に自動実行されます）"
echo ""

# ── Step 5: テスト送信 ──
echo "📧 Step 5: テスト送信を実行しますか？"
read -r -p "  [y/N]: " answer
if [[ "$answer" =~ ^[Yy]$ ]]; then
    echo ""
    echo "  送信中..."
    # last_run.txtを一時的に削除してテスト実行
    [ -f "$SCRIPT_DIR/last_run.txt" ] && mv "$SCRIPT_DIR/last_run.txt" "$SCRIPT_DIR/last_run.txt.bak"
    python3 "$SCRIPT_DIR/news_digest.py"
    # バックアップを戻す
    [ -f "$SCRIPT_DIR/last_run.txt.bak" ] && mv "$SCRIPT_DIR/last_run.txt.bak" "$SCRIPT_DIR/last_run.txt"
fi

echo ""
echo "================================================"
echo "  ✅ セットアップ完了！"
echo ""
echo "  毎朝6時に自動でAIニュースが届きます"
echo "  手動実行: run_digest.command をダブルクリック"
echo "  ログ確認: $SCRIPT_DIR/digest.log"
echo "================================================"
echo ""

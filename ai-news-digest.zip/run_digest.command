#!/bin/bash
# 毎朝6時のAIニュース便 — ダブルクリックで起動
cd "$(dirname "$0")"
SCRIPT_DIR="$(pwd)"
ENV_FILE="$SCRIPT_DIR/.env"
PYTHON="$(which python3)"

echo ""
echo "=============================="
echo "  毎朝6時のAIニュース便"
echo "=============================="
echo ""

# ── Pythonチェック ──────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "⚠️  Pythonがインストールされていません。"
    echo ""
    echo "  インストールを開始します..."
    echo "  画面にポップアップが表示されたら「インストール」をクリックしてください。"
    echo "  （インストールには5〜10分かかります）"
    echo ""
    xcode-select --install 2>/dev/null
    echo ""
    echo "  ✅ インストール完了後、もう一度 run_digest.command を"
    echo "     ダブルクリックしてください。"
    echo ""
    echo "=============================="
    echo "  Press any key to close..."
    echo "=============================="
    read -n 1
    exit 0
fi

# ── パッケージチェック ──────────────────────────────────
if ! python3 -c "import feedparser" 2>/dev/null; then
    echo "📦 必要なパッケージをインストールしています..."
    pip3 install --quiet feedparser python-dotenv anthropic \
                 gspread google-auth google-auth-oauthlib google-auth-httplib2
    echo "  ✅ インストール完了"
    echo ""
fi

# ── 初回セットアップ ────────────────────────────────────
if [ ! -f "$ENV_FILE" ]; then
    echo "🔧 初回セットアップを行います（1〜2分で完了します）"
    echo ""

    # Gmailアドレス
    echo "① Gmailアドレスを入力してください"
    read -r -p "   例) yourname@gmail.com : " gmail_addr
    echo ""

    # アプリパスワード
    echo "② Gmailのアプリパスワードを入力してください"
    echo "   ※取得方法: myaccount.google.com/security"
    echo "     → 2段階認証をON → アプリパスワードを生成"
    read -r -p "   例) abcd efgh ijkl mnop : " app_pass
    app_pass="${app_pass// /}"
    echo ""

    # 送信先
    echo "③ 受信するメールアドレスを入力してください"
    read -r -p "   （自分に送るならEnterでOK）[$gmail_addr]: " email_to
    email_to="${email_to:-$gmail_addr}"
    echo ""

    # Claude APIキー（オプション）
    echo "④ Claude APIキーを持っていますか？（持っていればAI要約になります）"
    read -r -p "   持っている場合は入力 / ない場合はEnter: " api_key
    echo ""

    # .envを書き出し
    if [ -n "$api_key" ]; then
        cat > "$ENV_FILE" << EOF
GMAIL_ADDRESS=${gmail_addr}
GMAIL_APP_PASSWORD=${app_pass}
EMAIL_TO=${email_to}
ANTHROPIC_API_KEY=${api_key}
USE_SHEETS=false
GOOGLE_EMAIL=${gmail_addr}
EOF
    else
        cat > "$ENV_FILE" << EOF
GMAIL_ADDRESS=${gmail_addr}
GMAIL_APP_PASSWORD=${app_pass}
EMAIL_TO=${email_to}
# ANTHROPIC_API_KEY=
USE_SHEETS=false
GOOGLE_EMAIL=${gmail_addr}
EOF
    fi

    echo "  ✅ 設定を保存しました"
    echo ""

    # LaunchAgent（毎朝6時の自動実行）
    PLIST_NAME="com.ainewsdigest.daily"
    PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"
    mkdir -p "$HOME/Library/LaunchAgents"

    cat > "$PLIST_PATH" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${PLIST_NAME}</string>
    <key>ProgramArguments</key>
    <array>
        <string>${PYTHON}</string>
        <string>${SCRIPT_DIR}/news_digest.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>6</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>StandardErrorPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>WorkingDirectory</key>
    <string>${SCRIPT_DIR}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
        <key>HOME</key>
        <string>${HOME}</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
PLIST

    launchctl unload "$PLIST_PATH" 2>/dev/null || true
    launchctl load "$PLIST_PATH"
    echo "  ✅ 毎朝6時の自動実行を登録しました"
    echo ""
    echo "  ─────────────────────────────"
    echo "  テスト送信します..."
    echo "  ─────────────────────────────"
    echo ""
fi

# ── LaunchAgentチェック（.envが既存でも未登録なら登録）──
PLIST_NAME="com.ainewsdigest.daily"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"
if ! launchctl list | grep -q "$PLIST_NAME"; then
    mkdir -p "$HOME/Library/LaunchAgents"
    cat > "$PLIST_PATH" << PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${PLIST_NAME}</string>
    <key>ProgramArguments</key>
    <array>
        <string>${PYTHON}</string>
        <string>${SCRIPT_DIR}/news_digest.py</string>
    </array>
    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>6</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>
    <key>StandardOutPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>StandardErrorPath</key>
    <string>${SCRIPT_DIR}/digest.log</string>
    <key>WorkingDirectory</key>
    <string>${SCRIPT_DIR}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>/usr/local/bin:/usr/bin:/bin:/opt/homebrew/bin</string>
        <key>HOME</key>
        <string>${HOME}</string>
    </dict>
    <key>RunAtLoad</key>
    <true/>
</dict>
</plist>
PLIST
    launchctl load "$PLIST_PATH"
    echo "  ✅ 毎朝6時の自動実行を登録しました"
fi

# ── メイン実行 ──────────────────────────────────────────
python3 "$SCRIPT_DIR/news_digest.py"

echo ""
echo "=============================="
echo "  Press any key to close..."
echo "=============================="
read -n 1
